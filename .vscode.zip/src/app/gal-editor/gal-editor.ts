import { Component, ViewEncapsulation, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface PhoneField {
  code: string;
  number: string;
}

@Component({
  selector: 'app-gal-editor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './gal-editor.html',
  styleUrl: './gal-editor.css',
  encapsulation: ViewEncapsulation.None
})
export class GalEditorComponent {
  staffNo = signal('');
  lastName = signal('');
  otherNames = signal('');
  initials = signal('');
  displayName = signal('');

  extension1: PhoneField = { code: '', number: '' };
  extension2: PhoneField = { code: '', number: '' };
  mobileNo: PhoneField = { code: '', number: '' };
  homePhone: PhoneField = { code: '', number: '' };
  fax: PhoneField = { code: '', number: '' };

  designation = signal('');
  office = signal('');
  section = signal('');
  costCenter = signal('');
  department = signal('');
  division = signal('');

  permanentAddress = signal('');
  galAddress = signal('');
  useAboveAsGal = signal(false);

  // Two-letter avatar initials derived from the display name; falls back to a
  // placeholder mark when nothing has been entered yet.
  avatarInitials = computed(() => {
    const parts = this.displayName().trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return '—';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  });

  onUseAboveAsGalChange(checked: boolean): void {
    this.useAboveAsGal.set(checked);
    if (checked) {
      this.galAddress.set(this.permanentAddress());
    }
  }

  onPermanentAddressChange(value: string): void {
    this.permanentAddress.set(value);
    if (this.useAboveAsGal()) {
      this.galAddress.set(value);
    }
  }

  reset(): void {
    this.staffNo.set('');
    this.lastName.set('');
    this.otherNames.set('');
    this.initials.set('');
    this.displayName.set('');
    this.extension1 = { code: '', number: '' };
    this.extension2 = { code: '', number: '' };
    this.mobileNo = { code: '', number: '' };
    this.homePhone = { code: '', number: '' };
    this.fax = { code: '', number: '' };
    this.designation.set('');
    this.office.set('');
    this.section.set('');
    this.costCenter.set('');
    this.department.set('');
    this.division.set('');
    this.permanentAddress.set('');
    this.galAddress.set('');
    this.useAboveAsGal.set(false);
  }

  save(): void {
    const payload = {
      staffNo: this.staffNo(),
      lastName: this.lastName(),
      otherNames: this.otherNames(),
      initials: this.initials(),
      displayName: this.displayName(),
      extension1: this.extension1,
      extension2: this.extension2,
      mobileNo: this.mobileNo,
      homePhone: this.homePhone,
      fax: this.fax,
      designation: this.designation(),
      office: this.office(),
      section: this.section(),
      costCenter: this.costCenter(),
      department: this.department(),
      division: this.division(),
      permanentAddress: this.permanentAddress(),
      galAddress: this.galAddress()
    };
    // Wire this up to your save endpoint
    console.log('Saving GAL entry', payload);
  }
}